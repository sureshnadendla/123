<html>
	<head>
		<link rel="stylesheet" type="text/css" href="../css/single_post.css" />
    	<link rel="stylesheet" type="text/css" href="../css/custom.css" />
    	<script type="text/javascript" src="../js/jquery-1.9.1.min.js"></script>
    	 <script type="text/javascript" src="../blog/wordpress/wp-content/plugins/silk-ajax-comments/ajaxcomments.js"></script>
    	     <link href='http://fonts.googleapis.com/css?family=Marko+One' rel='stylesheet' type='text/css'>

	</head>
	<body>
		<!-- #header -->
		
		<table class="header_content" width="100%" cellpadding="0" cellspacing="0">
			<tr>
				<td width="45%" class="post_header">
				    
			 <img src="Olamundologo.png" width="130px" height="35px" class="blog_logo" />
			</td>		
			<td class="post_menu_home"><span >
			<a class=" post_header_links" href="../index.php?curclicked=0">Home</a>
			</span></td>
			<td class="post_menu_blog"> <span >
			<a class=" post_header_links" href="../index.php?curclicked=1">Blog</a>
			</span></td>
			<td  class="post_menu_news"> <span>
			<a class="post_header_links" href="../index.php?curclicked=2">News</a>
			</span></td>
			<td class="post_menu_stories"><span >
			<a class=" post_header_links" href="../index.php?curclicked=3">Stories</a>
			</span> </td>
			<td class="post_menu_support"> <span >
			<a class=" post_header_links" href="../index.php?curclicked=4">Support</a>
			</span></td>
			</tr>
		</table>
		<!-- <div class="header_content">
		<span class="post_header">
		     
			 <img src="Olamundologo.png" width="130px" height="35px"  />
			</span>
			<span class="post_menu_home">
			<a>Home</a>
			</span>
			<span class="post_menu_blog">
			<a>Blog</a>
			</span>
			
			
			
			<!-- <div class="post_back">
				<a style="color:#ffffff;text-decoration: none" href="../index.php?curclicked=1">back to blogs</a>
			</div>
		</div>   -->
		<?php
		require ('wordpress/wp-blog-header.php');
		?>
		
		<div id="primary" class="site-content">
			<div id="content" role="main">

				<?php while ( have_posts() ) : the_post();
				?>

				<?php get_template_part('content', get_post_format()); ?>

				<?php comments_template('', true); ?>

				<?php endwhile; // end of the loop. ?>
			</div><!-- #content -->
		</div><!-- #primary -->
	<!-- 	#footer -->
	
<div class="footer">
    <img src="../images/footer/foot.png" width="100%" height="10px" class="nav-thumb" alt="temp-thumb" />

    <div class="footer_links">
        <ul  class="footer_li_text">
            <li class="footer_text_left">
                <a href="#" class="footer_text"> About </a>
            </li>
            <li>
                <a href="#" class="footer_text"> Stories </a>
            </li>
            <li>
                <a href="#" class="footer_text"> Events </a>
            </li>
            <li>
                <a href="#" class="footer_text"> Blogs </a>
            </li>
            <li>
                <a href="#" class="footer_text"> FAQ </a>
            </li>
            <li>
                <a href="#" class="footer_text"> Support </a>
            </li>
            <li>
                <a href="#" class="footer_text"> Download </a>
            </li>
        </ul>
    </div>



    <div class="footer_social_icons" >
        <ul class="footer_li_img">
            <li>
                <a href="https://accounts.google.com/ServiceLogin?service=oz&continue=https://plus.google.com/?hl%3Den%26gpsrc%3Dgplp0&hl=en" target="_blank"> <img src="../images/footer/googleplus.png" class="social_icons" alt="temp-thumb" /></a>
            </li>
            <li>
                <a href="https://www.linkedin.com/uas/login?session_redirect=https%3A%2F%2Fwww%2Elinkedin%2Ecom%2Fsettings%2F" target="_blank"> <img src="../images/footer/in.png" class="social_icons"   alt="temp-thumb" /></a>
            </li>
            <li>
                <a href="http://www.youtube.com/" target="_blank"> <img src="../images/footer/you.png" class="social_icons"   alt="temp-thumb" /></a>
            </li>
            <li>
                <a href="https://twitter.com/" target="_blank"> <img src="../images/footer/twitter.png" class="social_icons"   alt="temp-thumb" /></a>
            </li>
            <li>
                <a href="https://accounts.google.com/ServiceLogin?service=feedburner&continue=http%3A%2F%2Ffeedburner.google.com%2Ffb%2Fa%2Fmyfeeds&gsessionid=rDc9_Tp6FCMPAypL8JPRzA" target="_blank"> <img src="../images/footer/rss.png" class="social_icons"   alt="temp-thumb" /></a>
            </li>
            <li>
                <a href="https://www.facebook.com/" target="_blank"> <img src="../images/footer/fb.png" class="social_icons"   alt="temp-thumb" /></a>
            </li>
            <li>
                <a href="http://www.apple.com/itunes/what-is/#store" target="_blank"> <img src="../images/footer/apple.png" class="footer_apple_icon"   alt="temp-thumb" /></a>
            </li>
        </ul>
    </div>


<div class="footer_declaration">
    Legal stuff Sunt in culpa qui officia deserunt mollit anim id est laborumLorem ipsum dolor sit amet.Sunt in culpa
    qui officia deserunt mollit anim id est laborumLorem ipsum dolor sit amet. Sunt in culpa qui officia deserunt rum-
    Lorem ipsum dolor sit amet.Sunt in culpa qui officimollit anim id est laborumLorem ipsum dolor sit amet
</div>
</div>
	</body>
</html>