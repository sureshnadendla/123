<?php
/**
 * The base configurations of the WordPress.
 *
 * This file has the following configurations: MySQL settings, Table Prefix,
 * Secret Keys, WordPress Language, and ABSPATH. You can find more information
 * by visiting {@link http://codex.wordpress.org/Editing_wp-config.php Editing
 * wp-config.php} Codex page. You can get the MySQL settings from your web host.
 *
 * This file is used by the wp-config.php creation script during the
 * installation. You don't have to use the web site, you can just copy this file
 * to "wp-config.php" and fill in the values.
 *
 * @package WordPress
 */

// ** MySQL settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define('DB_NAME', 'olamundo_website');

/** MySQL database username */
define('DB_USER', 'root');

/** MySQL database password */
define('DB_PASSWORD', '');

/** MySQL hostname */
define('DB_HOST', 'localhost');

/** Database Charset to use in creating database tables. */
define('DB_CHARSET', 'utf8');

/** The Database Collate type. Don't change this if in doubt. */
define('DB_COLLATE', '');

/**#@+
 * Authentication Unique Keys and Salts.
 *
 * Change these to different unique phrases!
 * You can generate these using the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}
 * You can change these at any point in time to invalidate all existing cookies. This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define('AUTH_KEY',         'R)_<*Ij:S2{S>s+X$?_=v);hYf_JwWN9Uu~}sZ6;;Qq@f[zOQu+L:cT#U-L|3_s,');
define('SECURE_AUTH_KEY',  'h|T+vw-<Mv-|An<qv+,0aH8X}uJ%#u~tF=Id~BHQUUz!O?h|uoutl5,FBd2R4])|');
define('LOGGED_IN_KEY',    'w5x:} pzFfrAM[y>b%FM!Zm)r}Kj[XK+7> )DP8Sp/H`;+[qsI(R-_fTfa`ap`=`');
define('NONCE_KEY',        '|{+`n_sDY,6+%4jj27#sGtfZ4FvahZ*Fy&@)C[>kB.++U4~c1#|MpQ{blv|0M+%<');
define('AUTH_SALT',        'b4hdkZaU[Pif8xAW+|i-!|7Mi;.hP4p[%S;XxWJkuE@ShgL)-k^>W*7Btn/|].u=');
define('SECURE_AUTH_SALT', 'r+Sx,tqmMm)L[1YahLu0y~}/jI=->pzsg$t7tI>hm|Nl/Nnm&22C+f#KKVhwB[kf');
define('LOGGED_IN_SALT',   '_ziB;0x]5|RuACm;;Q(0vUa2[P-&^:3b_~v~pu`+*_q@/w<ndYSG-OuC-4nA#wbC');
define('NONCE_SALT',       'pQ6#]h<1z!Zmt4P+GIbzi7N:#MG^tp|BB{rYD0J|s&-@#i5!+av!F8-2*sz^BT._');

/**#@-*/

/**
 * WordPress Database Table prefix.
 *
 * You can have multiple installations in one database if you give each a unique
 * prefix. Only numbers, letters, and underscores please!
 */
$table_prefix  = 'wp_';

/**
 * WordPress Localized Language, defaults to English.
 *
 * Change this to localize WordPress. A corresponding MO file for the chosen
 * language must be installed to wp-content/languages. For example, install
 * de_DE.mo to wp-content/languages and set WPLANG to 'de_DE' to enable German
 * language support.
 */
define('WPLANG', '');

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 */
define('WP_DEBUG', false);

/* That's all, stop editing! Happy blogging. */

/** Absolute path to the WordPress directory. */
if ( !defined('ABSPATH') )
	define('ABSPATH', dirname(__FILE__) . '/');

/** Sets up WordPress vars and included files. */
require_once(ABSPATH . 'wp-settings.php');

