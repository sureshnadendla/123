<div class="footer">
       <img src="<?php bloginfo('template_directory'); ?>/images/foot.png" width="100%" height="10px"  title="" alt="" />

    <div class="footer_links">
        <ul  class="footer_li_text">
            <li class="footer_text_left">
                <a href="../../index.php?curclicked=0#about" class="footer_text"> About </a>
            </li>
            <li>
                <a href="../../index.php?curclicked=3" class="footer_text"> Stories </a>
            </li>
            <li>
                <a href="#" class="footer_text"> Events </a>
            </li>
            <li>
                <a href="../../index.php?curclicked=1" class="footer_text"> Blogs </a>
            </li>
            <li>
                <a href="../../index.php?curclicked=4" class="footer_text"> FAQ </a>
            </li>
            <li>
                <a href="../../index.php?curclicked=4" class="footer_text"> Support </a>
            </li>
            <li>
                <a href="http://www.apple.com/itunes/what-is/#store" target="_blank" class="footer_text"> Download </a>
            </li>
        </ul>
    </div>



    <div class="footer_social_icons" >
        <ul class="footer_li_img">
            <li>
                <a href="https://accounts.google.com/ServiceLogin?service=oz&continue=https://plus.google.com/?hl%3Den%26gpsrc%3Dgplp0&hl=en" target="_blank">
                	 
                	 		<img src="<?php bloginfo('template_directory'); ?>/images/googleplus.png"  class="social_icons" title="" alt="" />

                	 </a>
            </li>
            <li>
                <a href="https://www.linkedin.com/uas/login?session_redirect=https%3A%2F%2Fwww%2Elinkedin%2Ecom%2Fsettings%2F" target="_blank"> 
                	                	 		<img src="<?php bloginfo('template_directory'); ?>/images/in.png"  class="social_icons" title="" alt="" />

            </li>
            <li>
                <a href="http://www.youtube.com/" target="_blank"> 
              <img src="<?php bloginfo('template_directory'); ?>/images/you.png"  class="social_icons" title="" alt="" />
</a>
            </li>
            <li>
                <a href="https://twitter.com/" target="_blank"> 
                	                	                	 		
                <img src="<?php bloginfo('template_directory'); ?>/images/twitter.png"  class="social_icons" title="" alt="" />
</a>
            </li>
            <li>
                <a href="https://accounts.google.com/ServiceLogin?service=feedburner&continue=http%3A%2F%2Ffeedburner.google.com%2Ffb%2Fa%2Fmyfeeds&gsessionid=rDc9_Tp6FCMPAypL8JPRzA" target="_blank"> 
               <img src="<?php bloginfo('template_directory'); ?>/images/rss.png"  class="social_icons" title="" alt="" />
</a>
            </li>
            <li>
                <a href="https://www.facebook.com/" target="_blank"> 
               	<img src="<?php bloginfo('template_directory'); ?>/images/fb.png"  class="social_icons" title="" alt="" />
</a>
            </li>
            <li>
                <a href="http://www.apple.com/itunes/what-is/#store" target="_blank"> 
       <img src="<?php bloginfo('template_directory'); ?>/images/apple.png"  class="footer_apple_icon" title="" alt="" />

               </a>
            </li>
        </ul>
    </div>


<div class="footer_declaration">
    Legal stuff Sunt in culpa qui officia deserunt mollit anim id est laborumLorem ipsum dolor sit amet.Sunt in culpa
    qui officia deserunt mollit anim id est laborumLorem ipsum dolor sit amet. Sunt in culpa qui officia deserunt rum-
    Lorem ipsum dolor sit amet.Sunt in culpa qui officimollit anim id est laborumLorem ipsum dolor sit amet
</div>
</div>